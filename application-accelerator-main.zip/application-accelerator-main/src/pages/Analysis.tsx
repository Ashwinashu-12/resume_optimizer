
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Download,
  CopyCheck,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  DownloadCloud,
} from "lucide-react";

const Analysis = () => {
  const { toast } = useToast();
  const [expandedSections, setExpandedSections] = useState<string[]>([]);

  // Mock data for resume analysis
  const scoreData = {
    overallScore: 72,
    sections: [
      { name: "Content Relevance", score: 78 },
      { name: "Keyword Optimization", score: 65 },
      { name: "Experience Description", score: 82 },
      { name: "Skills Match", score: 70 },
      { name: "Formatting", score: 88 },
    ],
  };

  const suggestions = [
    {
      id: "s1",
      section: "Summary",
      original: "Results-driven software engineer with 5+ years of experience in developing web applications.",
      suggestion: "Results-driven software engineer with 5+ years of experience in developing responsive web applications using React and Node.js, with a focus on scalable architecture and performance optimization.",
      reason: "Adding specific technologies and focus areas that match the job description",
    },
    {
      id: "s2",
      section: "Experience",
      original: "Developed frontend features for the company's main product.",
      suggestion: "Engineered responsive UI components using React and Redux that improved user engagement by 32% and reduced load time by 45%.",
      reason: "Quantifying achievements and specifying technologies used",
    },
    {
      id: "s3",
      section: "Skills",
      original: "JavaScript, HTML, CSS, React",
      suggestion: "JavaScript (ES6+), React.js, Redux, Node.js, Express, MongoDB, AWS, CI/CD, Jest, TypeScript",
      reason: "Expanding the skills section with more specific technologies mentioned in the job description",
    },
  ];

  const missingKeywords = [
    "Docker", "Kubernetes", "GraphQL", "TypeScript", "CI/CD"
  ];

  const chartData = scoreData.sections.map(section => ({
    name: section.name,
    score: section.score,
  }));

  const toggleSection = (id: string) => {
    setExpandedSections(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id) 
        : [...prev, id]
    );
  };

  const downloadResume = () => {
    toast({
      title: "Resume Downloaded",
      description: "Your optimized resume has been downloaded successfully.",
    });
  };

  return (
    <div className="container max-w-5xl py-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8 text-center"
      >
        <h1 className="text-3xl font-bold mb-2">Resume Analysis</h1>
        <p className="text-muted-foreground">
          Here's our comprehensive analysis of your resume
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="lg:col-span-2 space-y-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Optimization Suggestions</CardTitle>
              <CardDescription>
                Actionable recommendations to improve your resume
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {suggestions.map((item) => (
                <div 
                  key={item.id} 
                  className="border rounded-lg overflow-hidden transition-all duration-300"
                >
                  <div 
                    className="flex justify-between items-center p-4 cursor-pointer bg-secondary/50"
                    onClick={() => toggleSection(item.id)}
                  >
                    <div className="font-medium flex items-center">
                      <CopyCheck className="h-5 w-5 text-primary mr-2" />
                      {item.section}
                    </div>
                    <Button variant="ghost" size="sm">
                      {expandedSections.includes(item.id) ? 
                        <ChevronUp className="h-4 w-4" /> : 
                        <ChevronDown className="h-4 w-4" />
                      }
                    </Button>
                  </div>
                  
                  {expandedSections.includes(item.id) && (
                    <div className="p-4 space-y-4 bg-card animate-slide-in">
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Original</h4>
                        <p className="p-3 bg-muted/50 rounded-md text-sm">{item.original}</p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-primary mb-1">Suggestion</h4>
                        <p className="p-3 bg-primary/5 rounded-md text-sm border border-primary/20">{item.suggestion}</p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Reasoning</h4>
                        <p className="text-sm text-muted-foreground">{item.reason}</p>
                      </div>
                      
                      <div className="flex justify-end">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            toast({
                              title: "Suggestion Applied",
                              description: "The suggestion has been applied to your optimized resume.",
                            });
                          }}
                        >
                          Apply Suggestion
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Missing Keywords</CardTitle>
              <CardDescription>
                Important keywords from the job description that are missing in your resume
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {missingKeywords.map((keyword, index) => (
                  <div 
                    key={index}
                    className="px-3 py-1.5 bg-destructive/10 text-destructive rounded-full text-sm flex items-center"
                  >
                    <AlertCircle className="h-3.5 w-3.5 mr-1.5" />
                    {keyword}
                  </div>
                ))}
              </div>
              
              <div className="mt-6">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    toast({
                      title: "Suggestions Added",
                      description: "Keyword suggestions have been added to your resume draft.",
                    });
                  }}
                >
                  Add All Keywords to Resume
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="space-y-8"
        >
          <Card>
            <CardHeader>
              <CardTitle>Resume Score</CardTitle>
              <CardDescription>
                How well your resume matches the job description
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="relative inline-flex">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-3xl font-bold">{scoreData.overallScore}%</span>
                  </div>
                  <svg className="w-36 h-36" viewBox="0 0 100 100">
                    <circle 
                      cx="50" cy="50" r="45" 
                      fill="none" 
                      stroke="#e5e7eb" 
                      strokeWidth="10" 
                    />
                    <circle 
                      cx="50" cy="50" r="45" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="10" 
                      strokeDasharray="282.7433388230814" 
                      strokeDashoffset={282.7433388230814 * (1 - scoreData.overallScore / 100)}
                      className="text-primary" 
                      transform="rotate(-90 50 50)" 
                    />
                  </svg>
                </div>
              </div>
              
              <div className="space-y-4">
                {scoreData.sections.map((section, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1 text-sm">
                      <span>{section.name}</span>
                      <span className="font-medium">{section.score}%</span>
                    </div>
                    <Progress value={section.score} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Score Breakdown</CardTitle>
              <CardDescription>
                Visual representation of your resume scores
              </CardDescription>
            </CardHeader>
            <CardContent className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{
                    top: 5,
                    right: 5,
                    left: 5,
                    bottom: 35,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 12 }} 
                    angle={-45} 
                    textAnchor="end"
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    tick={{ fontSize: 12 }} 
                    width={30}
                  />
                  <Tooltip />
                  <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle>Optimized Resume</CardTitle>
              <CardDescription>
                Download your improved resume
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center py-6">
              <div className="bg-primary/10 rounded-full p-4 mb-4">
                <CheckCircle2 className="h-12 w-12 text-primary" />
              </div>
              <p className="text-center mb-6">
                Your resume has been optimized with all suggestions applied
              </p>
              <Button onClick={downloadResume} className="w-full">
                <DownloadCloud className="mr-2 h-4 w-4" />
                Download Optimized Resume
              </Button>
            </CardContent>
            <motion.div 
              className="absolute -top-10 -right-10 h-24 w-24 bg-primary/10 rounded-full blur-2xl"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 5 }}
            />
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="flex justify-center mt-12"
      >
        <Link to="/dashboard">
          <Button size="lg" variant="outline">
            View All Analytics
          </Button>
        </Link>
      </motion.div>
    </div>
  );
};

export default Analysis;
