
import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Sparkles, 
  CheckCircle, 
  ChevronRight 
} from "lucide-react";

const Index = () => {
  const { toast } = useToast();

  const features = [
    {
      icon: <FileText className="h-6 w-6 text-primary" />,
      title: "Resume Analysis",
      description: "AI-powered analysis of your resume to identify strengths and weaknesses",
    },
    {
      icon: <Sparkles className="h-6 w-6 text-primary" />,
      title: "Smart Suggestions",
      description: "Get personalized suggestions to improve your resume based on job descriptions",
    },
    {
      icon: <CheckCircle className="h-6 w-6 text-primary" />,
      title: "ATS Optimization",
      description: "Ensure your resume passes Applicant Tracking Systems with keyword optimization",
    },
  ];

  return (
    <div className="mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center py-12 md:py-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-3xl mx-auto"
        >
          <span className="inline-block px-3 py-1 mb-6 text-xs font-medium tracking-wider text-primary bg-primary/10 rounded-full">
            AI-POWERED RESUME OPTIMIZATION
          </span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
            Your resume, <span className="text-primary text-glow">optimized</span> for success
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Leverage AI to analyze and improve your resume, increasing your chances of landing interviews and securing your dream job.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/resume">
              <Button size="lg" className="group">
                Optimize Resume
                <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => {
                toast({
                  title: "How It Works",
                  description: "Our AI analyzes your resume against job descriptions and industry standards.",
                });
              }}
            >
              Learn How It Works
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Features Section */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="py-12 md:py-24"
      >
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Key Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our platform combines advanced AI with resume best practices to help you stand out
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 * index + 0.5, duration: 0.5 }}
              className="glass-card p-6 h-full flex flex-col"
            >
              <div className="rounded-full p-3 bg-primary/10 w-fit mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* CTA Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.6 }}
        className="py-12 md:py-24"
      >
        <div className="glass-panel p-8 md:p-12 flex flex-col items-center text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to improve your resume?</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl">
            Upload your resume now and get instant feedback and suggestions to make it stand out to employers and recruiters.
          </p>
          <Link to="/resume">
            <Button size="lg" className="group">
              Get Started
              <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default Index;
