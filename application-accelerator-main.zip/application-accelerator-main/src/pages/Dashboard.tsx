import React from "react";
import { motion } from "framer-motion";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Activity,
  TrendingUp,
  Users,
  Calendar,
  Clock,
  BarChart3,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  Download,
  Eye,
  FileText,
} from "lucide-react";

const Dashboard = () => {
  const { toast } = useToast();
  
  // Mock data for dashboard
  const resumeActivityData = [
    { name: "Jan", uploads: 2, optimizations: 1 },
    { name: "Feb", uploads: 3, optimizations: 2 },
    { name: "Mar", uploads: 5, optimizations: 4 },
    { name: "Apr", uploads: 4, optimizations: 3 },
    { name: "May", uploads: 7, optimizations: 6 },
    { name: "Jun", uploads: 8, optimizations: 7 },
  ];
  
  const scoreProgressData = [
    { name: "Resume 1", initial: 48, optimized: 76 },
    { name: "Resume 2", initial: 52, optimized: 83 },
    { name: "Resume 3", initial: 67, optimized: 91 },
  ];
  
  const keywordDistributionData = [
    { name: "Technical Skills", value: 35 },
    { name: "Experience", value: 25 },
    { name: "Education", value: 15 },
    { name: "Soft Skills", value: 15 },
    { name: "Certifications", value: 10 },
  ];
  
  const COLORS = ["#3b82f6", "#6366f1", "#8b5cf6", "#a855f7", "#d946ef"];
  
  const stats = [
    { 
      title: "Resumes Optimized", 
      value: "12", 
      icon: <Activity className="h-4 w-4" />,
      change: "+50%",
      trend: "up"
    },
    { 
      title: "Average Score Improvement", 
      value: "32%", 
      icon: <TrendingUp className="h-4 w-4" />,
      change: "+5%",
      trend: "up"
    },
    { 
      title: "Application Readiness", 
      value: "85%", 
      icon: <Users className="h-4 w-4" />,
      change: "+12%",
      trend: "up"
    },
    { 
      title: "Last Optimization", 
      value: "2 days ago", 
      icon: <Calendar className="h-4 w-4" />,
      change: "",
      trend: "neutral"
    },
  ];
  
  const recentResumes = [
    { id: 1, name: "Software Engineer - Google.pdf", date: "Jun 12, 2023", score: 88 },
    { id: 2, name: "Product Manager - Amazon.pdf", date: "May 27, 2023", score: 92 },
    { id: 3, name: "Data Scientist - Microsoft.pdf", date: "May 15, 2023", score: 76 },
  ];

  return (
    <div className="container py-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row md:items-center md:justify-between mb-8"
      >
        <div>
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Track your resume optimization progress and insights
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button
            onClick={() => {
              toast({
                title: "Report Generated",
                description: "Your optimization report has been generated and downloaded.",
              });
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
      >
        {stats.map((stat, index) => (
          <Card key={index} className="overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  {stat.change && (
                    <p className={`text-xs flex items-center ${
                      stat.trend === 'up' 
                        ? 'text-emerald-500' 
                        : stat.trend === 'down' 
                          ? 'text-red-500' 
                          : 'text-muted-foreground'
                    }`}>
                      {stat.trend === 'up' && '↑ '}
                      {stat.trend === 'down' && '↓ '}
                      {stat.change}
                    </p>
                  )}
                </div>
                <div className="rounded-full p-2 bg-primary/10">
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="lg:col-span-2"
        >
          <Tabs defaultValue="activity">
            <div className="flex items-center justify-between mb-4">
              <TabsList>
                <TabsTrigger value="activity" className="flex items-center">
                  <LineChartIcon className="h-4 w-4 mr-1" />
                  Activity
                </TabsTrigger>
                <TabsTrigger value="progress" className="flex items-center">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Progress
                </TabsTrigger>
              </TabsList>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => {
                  toast({
                    title: "Data Refreshed",
                    description: "Dashboard data has been updated with the latest information.",
                  });
                }}
              >
                Refresh
              </Button>
            </div>
            
            <Card>
              <TabsContent value="activity" className="mt-0">
                <CardHeader>
                  <CardTitle>Resume Activity</CardTitle>
                  <CardDescription>
                    Track your resume uploads and optimizations over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={resumeActivityData}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)",
                            borderRadius: "8px",
                            border: "none",
                            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)"
                          }} 
                        />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="uploads"
                          stroke="#8884d8"
                          strokeWidth={2}
                          activeDot={{ r: 8 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="optimizations" 
                          stroke="#3b82f6" 
                          strokeWidth={2} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </TabsContent>
              
              <TabsContent value="progress" className="mt-0">
                <CardHeader>
                  <CardTitle>Score Improvement</CardTitle>
                  <CardDescription>
                    Compare your initial and optimized resume scores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={scoreProgressData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" />
                        <YAxis domain={[0, 100]} />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)",
                            borderRadius: "8px",
                            border: "none",
                            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)"
                          }} 
                        />
                        <Legend />
                        <Bar dataKey="initial" fill="#94a3b8" name="Initial Score" />
                        <Bar dataKey="optimized" fill="#3b82f6" name="Optimized Score" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </TabsContent>
            </Card>
          </Tabs>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <Card className="h-full flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center">
                <PieChartIcon className="h-5 w-5 mr-2 text-primary" />
                Keyword Distribution
              </CardTitle>
              <CardDescription>
                Keyword types in your optimized resume
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col justify-center">
              <div className="h-64 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={keywordDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({
                        cx,
                        cy,
                        midAngle,
                        innerRadius,
                        outerRadius,
                        percent,
                      }) => {
                        const radius = innerRadius + (outerRadius - innerRadius) * 1.3;
                        const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                        const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                        return (
                          <text
                            x={x}
                            y={y}
                            fill="#888888"
                            textAnchor={x > cx ? "start" : "end"}
                            dominantBaseline="central"
                            fontSize="12"
                          >
                            {`${(percent * 100).toFixed(0)}%`}
                          </text>
                        );
                      }}
                    >
                      {keywordDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {keywordDistributionData.map((entry, index) => (
                  <div key={index} className="flex items-center text-sm">
                    <div 
                      className="w-3 h-3 rounded-full mr-2" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }} 
                    />
                    <span className="text-muted-foreground">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="mt-8"
      >
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Recent Resumes</CardTitle>
                <CardDescription>
                  Your recently optimized resumes
                </CardDescription>
              </div>
              <Button variant="outline" size="sm">View All</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentResumes.map((resume) => (
                <div 
                  key={resume.id}
                  className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center">
                    <div className="rounded-full p-2 bg-primary/10 mr-3">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{resume.name}</p>
                      <p className="text-xs text-muted-foreground flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {resume.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center bg-primary/10 text-primary text-sm font-medium px-2.5 py-0.5 rounded-full">
                      {resume.score}%
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default Dashboard;
