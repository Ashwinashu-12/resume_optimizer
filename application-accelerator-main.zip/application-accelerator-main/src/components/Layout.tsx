
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { 
  Home, FileText, BarChart3, Lightbulb, Menu, X, Github
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { toast } = useToast();
  const location = useLocation();
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { path: "/", label: "Home", icon: <Home className="h-5 w-5" /> },
    { path: "/resume", label: "Resume", icon: <FileText className="h-5 w-5" /> },
    { path: "/dashboard", label: "Dashboard", icon: <BarChart3 className="h-5 w-5" /> },
    { path: "/analysis", label: "Analysis", icon: <Lightbulb className="h-5 w-5" /> },
  ];

  const pageVariants = {
    initial: {
      opacity: 0,
      y: 10,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: [0.22, 1, 0.36, 1],
      },
    },
    exit: {
      opacity: 0,
      y: -10,
      transition: {
        duration: 0.3,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-background/80 border-b border-border/40">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="relative h-8 w-8 overflow-hidden rounded-full bg-primary">
              <motion.div 
                className="absolute inset-0 flex items-center justify-center text-white font-bold"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, repeatDelay: 5, duration: 1 }}
              >
                R
              </motion.div>
            </div>
            <motion.span 
              className="font-medium text-xl hidden sm:inline-block"
              initial={{ opacity: 0, x: -5 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1, duration: 0.5 }}
            >
              ResumeAI
            </motion.span>
          </Link>

          {isMobile ? (
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? 
                <X className="h-5 w-5" /> : 
                <Menu className="h-5 w-5" />
              }
            </Button>
          ) : (
            <nav className="flex items-center space-x-1">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={location.pathname === item.path ? "default" : "ghost"}
                    size="sm"
                    className="relative group"
                  >
                    <span className="flex items-center gap-1.5">
                      {item.icon}
                      {item.label}
                    </span>
                    {location.pathname === item.path && (
                      <motion.span
                        layoutId="activeNavItem"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.2 }}
                      />
                    )}
                  </Button>
                </Link>
              ))}
              
              <Button 
                variant="outline" 
                size="sm" 
                className="ml-4"
                onClick={() => {
                  toast({
                    title: "GitHub Repository",
                    description: "This project's code is open source!",
                  });
                }}
              >
                <Github className="mr-1.5 h-4 w-4" />
                GitHub
              </Button>
            </nav>
          )}
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobile && mobileMenuOpen && (
          <motion.div
            className="fixed inset-0 z-30 flex flex-col pt-16 bg-background/95 backdrop-blur-sm"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <nav className="flex flex-col space-y-2 p-4">
              {navItems.map((item) => (
                <Link 
                  key={item.path} 
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Button
                    variant={location.pathname === item.path ? "default" : "ghost"}
                    size="lg"
                    className="w-full justify-start"
                  >
                    {item.icon}
                    <span className="ml-2">{item.label}</span>
                  </Button>
                </Link>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="min-h-[calc(100vh-4rem)]"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="py-6 md:px-8 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground">
            Built with precision & care. © 2023 ResumeAI. All rights reserved.
          </p>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs"
              onClick={() => {
                toast({
                  title: "Terms of Service",
                  description: "Our terms of service are available on request.",
                });
              }}
            >
              Terms
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs"
              onClick={() => {
                toast({
                  title: "Privacy Policy",
                  description: "We respect your privacy and protect your data.",
                });
              }}
            >
              Privacy
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
